/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bsu.fpmi.educational_practice;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

public class Information extends Canvas{
    private float diam;
    private Color iColor = null;
    private Color bColor = null;
    private float x , y;
    
    private Information(){}
    
    public Color getIColor() {return this.iColor;}
    public Color getBColor() {return this.bColor;}
    public float getDiam() {return this.diam;}
    
    public void setIColor(Color tmp){
        this.iColor = tmp;
    }
    public void setBColor(Color tmp){
        this.bColor = tmp;
    }
    public void setDiam(float tmp){
        this.diam = tmp;
    }
    
    public void setX(int x){this.x = x;}
    public void setY(int y){this.y = y;}
    
    public Information(Color i, Color b, int diam){
        setIColor(i);
        setBColor(b);
        setDiam(diam);
        
    }
    
    @Override
    public void paint(Graphics g){
        Graphics2D g2d = (Graphics2D)g;
        Shape circle = new Ellipse2D.Float(0, 0 ,diam, diam );
        g2d.draw(circle);
        g2d.setColor(bColor);
        g2d.fill(circle);
        
        g2d.setColor(iColor);
        
        Shape small = new Rectangle2D.Float(diam/2 - diam/12, diam/16 ,diam/16 + diam/8, diam/8 );
        Shape rec = new Rectangle2D.Float(diam/2 - diam/12, diam/16 + diam/6 ,diam/16 + diam/8, 11*diam/16);
        g2d.draw(small);
        g2d.draw(rec);
        g2d.fill(small);
        g2d.fill(rec);
    }
}
