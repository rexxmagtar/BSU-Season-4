/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import bsu.fpmi.educational_practice.Information;
import java.awt.*;
import java.applet.Applet;

public class test extends Applet{
    
    private Information inf  = null;
    private final int X= 300, Y = 400;
    
    @Override
    public void init(){
        setSize(X, Y);
        inf = new Information(new Color(250,0,0), new Color(0,250,250), 300);        
    }
    
    @Override
    public void paint(Graphics g){
      inf.paint(g);
    }
}
