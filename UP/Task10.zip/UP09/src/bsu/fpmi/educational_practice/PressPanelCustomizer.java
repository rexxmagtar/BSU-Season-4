package bsu.fpmi.educational_practice;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PressPanelCustomizer
	extends Panel
	implements Customizer, TextListener
{
	private PressPanel bean;
	private TextArea[] areas;

	@Override
	public void setObject(Object bean)
	{
		this.bean = (PressPanel) bean;

		setLayout(new BorderLayout());

		Panel labelsPanel = new Panel();
		labelsPanel.setPreferredSize(new Dimension(400, 50));
		labelsPanel.setLayout(new GridLayout(1, 3, 10, 10));
		labelsPanel.add(new Label("Update the symbols"));
		labelsPanel.add(new Label("Update the label texts"));
		labelsPanel.add(new Label("Update the button texts"));
		add(labelsPanel, BorderLayout.NORTH);

		areas = new TextArea[3];
		areas[0] = new TextArea();
		areas[1] = new TextArea();
		areas[2] = new TextArea();

		Panel areasPanel = new Panel();
		areasPanel.setPreferredSize(new Dimension(400, 200));
		areasPanel.setLayout(new GridLayout(1, 3, 10, 10));
		for (int i = 0;  i < 3; ++i)
		{
			TextArea area = areas[i];

			area.addTextListener(this);
			List<String> lines = new ArrayList<>();
			switch (i)
			{
				case 0:
					lines = PressPanelConfirmSymbolEditor.getSymbols();
					break;
				case 1:
					lines = PressPanelLabelTextEditor.getTexts();
					break;
				case 2:
					lines = PressPanelButtonTextEditor.getTexts();
					break;
			}
			area.setText(String.join("\n", lines));

			areasPanel.add(area);
		}
		add(areasPanel, BorderLayout.CENTER);
	}

	@Override
	public void textValueChanged(TextEvent e)
	{
		TextArea area = (TextArea) e.getSource();
		String text = area.getText();
		List<String> lines =
			Arrays.stream(text.split("\n"))
			.filter(str -> !str.equals(""))
			.collect(Collectors.toList());
		if (area == areas[0])
			PressPanelConfirmSymbolEditor.setSymbols(lines);
		else if (area == areas[1])
			PressPanelLabelTextEditor.setTexts(lines);
		else
			PressPanelButtonTextEditor.setTexts(lines);
	}
}
