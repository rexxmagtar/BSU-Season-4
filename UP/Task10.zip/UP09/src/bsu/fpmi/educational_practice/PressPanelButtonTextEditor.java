package bsu.fpmi.educational_practice;

import java.beans.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class PressPanelButtonTextEditor
	implements PropertyEditor
{
	private String text = TEXTS.get(0);
	private PropertyChangeSupport listeners = new PropertyChangeSupport(this);

	private static java.util.List<String> TEXTS =
		Arrays.asList("OK", "Confirm", "Approve", "Send", "Generate");

	public static java.util.List<String> getTexts()
	{
		return TEXTS;
	}

	public static void setTexts(java.util.List<String> texts)
	{
		TEXTS = texts;
	}

	@Override
	public String[] getTags()
	{
		return TEXTS.toArray(new String[0]);
	}

	@Override
	public void setValue(Object value)
	{
		setAsText(value.toString());
	}

	@Override
	public void setAsText(String text)
		throws IllegalArgumentException
	{
		this.text = text;
	}

	@Override
	public Object getValue()
	{
		return getAsText();
	}

	@Override
	public String getAsText()
	{
		if (!TEXTS.contains(text))
			text = TEXTS.get(0);
		return text;
	}

	@Override
	public boolean isPaintable()
	{
		return true;
	}

	@Override
	public void paintValue(Graphics gfx, Rectangle box)
	{
		gfx.setClip(box);
		gfx.drawString("Choose the button text", box.x + 5, box.y + 15);
	}

	@Override
	public String getJavaInitializationString()
	{
		return String.format("\"%s\"", text);
	}

	@Override
	public boolean supportsCustomEditor()
	{
		return false;
	}

	@Override
	public Component getCustomEditor()
	{
		return null;
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener)
	{
		listeners.addPropertyChangeListener(listener);
	}

	@Override
	public void removePropertyChangeListener(PropertyChangeListener listener)
	{
		listeners.removePropertyChangeListener(listener);
	}
}