package bsu.fpmi.educational_practice;

import java.util.*;

public class PressEvent
	extends EventObject
{
	private String text;
	private boolean buttonPressed;

	public PressEvent(Object source,
					  String text,
					  boolean buttonPressed)
	{
		super(source);
		this.text = text;
		this.buttonPressed = buttonPressed;
	}

	public String getText()
	{
		return text;
	}

	public boolean isButtonPressed()
	{
		return buttonPressed;
	}
}
