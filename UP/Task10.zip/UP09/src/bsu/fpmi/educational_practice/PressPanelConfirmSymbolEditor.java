package bsu.fpmi.educational_practice;

import java.beans.*;
import java.awt.*;
import java.security.InvalidParameterException;
import java.util.*;
import java.util.List;

public class PressPanelConfirmSymbolEditor
	implements PropertyEditor
{
	private char symbol = SYMBOLS.get(0).charAt(0);
	private PropertyChangeSupport listeners = new PropertyChangeSupport(this);

	private static java.util.List<String> SYMBOLS =
		Arrays.asList(".", ",", "!", "?", "*", "$");

	public static List<String> getSymbols()
	{
		return SYMBOLS;
	}

	public static void setSymbols(List<String> symbols)
	{
		for (var symbol : symbols)
			if (symbol.length() != 1)
				throw new IllegalArgumentException();
		SYMBOLS = symbols;
	}

	@Override
	public String[] getTags()
	{
		return SYMBOLS.toArray(new String[0]);
	}

	@Override
	public void setValue(Object value)
	{
		setAsText(value.toString());
	}

	@Override
	public void setAsText(String text)
		throws IllegalArgumentException
	{
		if (text.length() != 1)
			throw new InvalidParameterException("We need only one symbol!");
		symbol = text.charAt(0);
	}

	@Override
	public Object getValue()
	{
		return symbol;
	}

	@Override
	public String getAsText()
	{
		return Character.toString(symbol);
	}

	@Override
	public boolean isPaintable()
	{
		return true;
	}

	@Override
	public void paintValue(Graphics gfx, Rectangle box)
	{
		gfx.setClip(box);
		gfx.drawString("Choose the symbol", box.x + 5, box.y + 15);
	}

	@Override
	public String getJavaInitializationString()
	{
		return String.format("\"%c\"", symbol);
	}

	@Override
	public boolean supportsCustomEditor()
	{
		return false;
	}

	@Override
	public Component getCustomEditor()
	{
		return null;
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener)
	{
		listeners.addPropertyChangeListener(listener);
	}

	@Override
	public void removePropertyChangeListener(PropertyChangeListener listener)
	{
		listeners.removePropertyChangeListener(listener);
	}
}
