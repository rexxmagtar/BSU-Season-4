package bsu.fpmi.educational_practice;

import java.util.*;

public interface PressListener
	extends EventListener
{
	void press(PressEvent event);
}
