package bsu.fpmi.educational_practice;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import static javax.swing.JOptionPane.*;

public class PressPanel
	extends Panel
{
	private Button confirmButton;
	private Label textLabel;
	private TextArea textBox;
	private char confirmSymbol;
	private ArrayList<PressListener> listeners;

	private void positionControls()
	{
		add(textLabel, BorderLayout.NORTH);
		add(textBox, BorderLayout.CENTER);
		add(confirmButton, BorderLayout.SOUTH);
	}

	private void setListeners()
	{
		textBox.addTextListener
			(
				e ->
				{
					if (textBox.getText().charAt(textBox.getText().length() - 1) == confirmSymbol)
						fireEvent(textBox);
				}
			);
		confirmButton.addActionListener(e -> fireEvent(confirmButton));
	}

	private void fireEvent(Object sender)
	{
		PressEvent event = new PressEvent(sender,
										  textBox.getText(),
										  sender == confirmButton);

		for (PressListener listener : listeners)
			listener.press(event);
	}

	public PressPanel()
	{
		this("Your Text Here",
			 "OK",
			 '$');
	}

	public PressPanel(String labelText,
					  String buttonText,
					  char confirmSymbol)
	{
		setSize(300, 100);
		setLayout(new BorderLayout(10, 10));

		listeners = new ArrayList<>();
		confirmButton = new Button(buttonText);
		textLabel = new Label(labelText);
		textBox = new TextArea();
		setConfirmSymbol(confirmSymbol);

		positionControls();
		setListeners();
	}

	public char getConfirmSymbol()
	{
		return confirmSymbol;
	}

	public String getLabelText()
	{
		return textLabel.getText();
	}

	public String getButtonText()
	{
		return confirmButton.getLabel();
	}

	public void setConfirmSymbol(char confirmSymbol)
	{
		this.confirmSymbol = confirmSymbol;
	}

	public void setLabelText(String labelText)
	{
		textLabel.setText(labelText);
		validate();
	}

	public void setButtonText(String buttonText)
	{
		confirmButton.setLabel(buttonText);
		validate();
	}

	public void addPressListener(PressListener listener)
	{
		listeners.add(listener);
	}

	public void removePressListener(PressListener listener)
	{
		listeners.remove(listener);
	}

	public static void main(String[] args)
	{
		Frame frame = new Frame("Press Panel Test");
		frame.setSize(300, 100);
		frame.addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});

		PressPanel panel = new PressPanel("Type the text and press the button:", "Confirm", '^');
		panel.addPressListener(e -> showMessageDialog(panel, "Text: " + e.getText() + "\nWas button pressed? " + e.isButtonPressed()));

		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}
}
