package bsu.fpmi.educational_practice;

import java.beans.*;

public class PressPanelBeanInfo
	extends SimpleBeanInfo
{
	private static PropertyDescriptor prop(String name, String description)
	{
		try
		{
			PropertyDescriptor p =
				new PropertyDescriptor(name, PressPanel.class);
			p.setShortDescription(description);
			return p;
		}
		catch (IntrospectionException e)
		{
			return null;
		}
	}

	@Override
	public BeanDescriptor getBeanDescriptor()
	{
		return new BeanDescriptor(PressPanel.class,
								  PressPanelCustomizer.class);
	}

	private static final PropertyDescriptor[] PROPERTY_DESCRIPTORS =
	{
		prop("labelText", "The text to be shown on the label"),
		prop("buttonText", "The text to be shown on the button"),
		prop("confirmSymbol", "The confirmation symbol for the panel")
	};
	static
	{
		PROPERTY_DESCRIPTORS[0].setPropertyEditorClass
			(PressPanelLabelTextEditor.class);
		PROPERTY_DESCRIPTORS[1].setPropertyEditorClass
			(PressPanelButtonTextEditor.class);
		PROPERTY_DESCRIPTORS[2].setPropertyEditorClass
			(PressPanelConfirmSymbolEditor.class);
	}

	@Override
	public PropertyDescriptor[] getPropertyDescriptors()
	{
		return PROPERTY_DESCRIPTORS;
	}

	@Override
	public int getDefaultPropertyIndex()
	{
		return 0;
	}
}
