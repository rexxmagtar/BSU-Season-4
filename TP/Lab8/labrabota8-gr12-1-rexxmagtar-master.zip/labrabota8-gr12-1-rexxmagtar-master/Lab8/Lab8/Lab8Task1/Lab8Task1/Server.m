//
//  Server.m
//  Lab8Task1
//
//  Created by Ivan on 25.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Server.h"

@implementation Server

+(void) GetBrushRgb:(UIColor *)color Value2:(CGFloat *)r Value3:(CGFloat *)g Value4:(CGFloat *)b Valu5:(CGFloat *)a{
    
    [color getRed:r green:g blue:b alpha:a];

};

@end
