//
//  ViewController.m
//  Lab8Task1
//
//  Created by Ivan on 23.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import "ViewController.h"
#import "Server.h"
#import <QuartzCore/QuartzCore.h>

@interface ViewController ()

@property CGFloat r;
@property CGFloat g;
@property CGFloat b;
@property CGFloat a;
@property CGFloat width;
@property (weak, nonatomic) IBOutlet UITextField *WidthField;


@end

@implementation ViewController

///Handles first touch
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch* touch=[touches anyObject ];
    [self setLastPoint:[touch locationInView:self.view]];
    
}
- (IBAction)RedColorSwap:(id)sender {
    
    [self SetBrushRgb:UIColor.redColor];
}
- (IBAction)YellowColorSwap:(id)sender {
    [self SetBrushRgb:UIColor.yellowColor];
}
- (IBAction)GreenColorSwap:(id)sender {
    [self SetBrushRgb:UIColor.greenColor];
}
- (IBAction)GrayColorSwap:(id)sender {
    [self SetBrushRgb:UIColor.grayColor];
}
- (IBAction)BlueColorSwap:(id)sender {
    [self SetBrushRgb:UIColor.blueColor];
}

-(void) SetBrushRgb:(UIColor*) color {
    CGFloat r1=[self r];
      CGFloat g1=[self g];
      CGFloat b1=[self b];
      CGFloat a1=[self a];
    
    [color getRed:&r1 green:&g1 blue:&b1 alpha:&a1];
    
    
    self.r = r1;
    self.g = g1;
    self.b = b1;
    self.a = a1;
    
    
    
//      [Server GetBrushRgb:color Value2:&r1 Value3:&g1 Value4:&b1 Valu5:&a1];
};
- (IBAction)WidthChanged:(id)sender {
    self.width=([_WidthField.text intValue]);
}
- (IBAction)SaveClicked:(id)sender {
    

    // create graphics context with screen size
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    UIGraphicsBeginImageContext(screenRect.size);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    [[UIColor blackColor] set];
    CGContextFillRect(ctx, screenRect);
     
    // grab reference to our window
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
     
    // transfer content into our context
    [window.layer renderInContext:ctx];
    UIImage *screengrab = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // Create path.
 NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;

    UIImage * imageToSave = screengrab;
    NSData * binaryImageData = UIImagePNGRepresentation(imageToSave);

    [binaryImageData writeToFile:[basePath stringByAppendingPathComponent:@"myfile.png"] atomically:YES];

    // Save image.
    [UIImagePNGRepresentation(screengrab) writeToFile:basePath atomically:YES];
    
    _Canvas.image=screengrab;
    
    
}
///Handles new  touch moved
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint currentPoint = [touch locationInView:self.view];
    UIGraphicsBeginImageContext(self.view.frame.size);
    CGRect drawRect = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.view.frame.size.height);
    
    [[[self Canvas] image] drawInRect:drawRect]; CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound); CGContextSetLineWidth(UIGraphicsGetCurrentContext(), [_WidthField.text floatValue ]); CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), self.r, self.g, self.b, self.a); CGContextBeginPath(UIGraphicsGetCurrentContext()); CGContextMoveToPoint(UIGraphicsGetCurrentContext(), _lastPoint.x,
    _lastPoint.y);
    
    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(),
                            currentPoint.x,currentPoint.y);
    
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    [[self Canvas] setImage:UIGraphicsGetImageFromCurrentImageContext()]; UIGraphicsEndImageContext();
    _lastPoint = currentPoint;
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
