//
//  ViewController.h
//  Lab8Task1
//
//  Created by Ivan on 23.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *Canvas;
@property CGPoint lastPoint;

@end

