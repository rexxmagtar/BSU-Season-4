//
//  AppDelegate.h
//  Lab8Task1
//
//  Created by Ivan on 23.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

