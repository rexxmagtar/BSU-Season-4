//
//  ViewController.swift
//  Task14Lab8
//
//  Created by Ivan on 23.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        Label.isUserInteractionEnabled=true;
        Label.textAlignment = NSTextAlignment.center; Label.numberOfLines = 2; Label.text = "Используйте жесты в этой области";
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var Image: UIImageView!
    
    @IBAction func Action1(_ sender: Any) {
        
    }
    
    //Handle long press
    @IBAction func LongPress(_ sender: Any) {
         Image.image = UIImage(named: "Storm")!;
        Label.text = "Жест: долгое нажатие\n Цвет фона: оранжевый"
        Label.backgroundColor = UIColor.orange
    }
    
      //Handle tap
    @IBAction func Tap(_ sender: Any) {
        Image.image = UIImage(named: "Pudge")!;
        Label.text = "Жест: касание\n Цвет фона: зеленый"; Label.backgroundColor = UIColor.green;
    }
      //Handle swipe
    @IBAction func Swipe(_ sender: Any) {
          Image.image =  UIImage(named: "Techies")!;
        Label.text = "Жест: смахивание\n Цвет фона: серый"; Label.backgroundColor = UIColor.lightGray
    }
    
      //Handle Pinch
    @IBAction func Pinch(_ sender: Any) {
          Image.image =  UIImage(named: "Gabe")!;
        Label.text = "Жест: масштабирование\n Цвет фона: красный"; Label.backgroundColor = UIColor.red
    }
      //Handle rotation
    @IBAction func Rotate(_ sender: Any) {
          Image.image =  UIImage(named: "Dota2")!;
        Label.text = "Жест: вращение\n Цвет фона: синий"
        Label.backgroundColor = UIColor.blue
    }
}

