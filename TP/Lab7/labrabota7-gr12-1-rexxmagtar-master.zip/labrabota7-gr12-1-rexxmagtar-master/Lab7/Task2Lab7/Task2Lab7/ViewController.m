//
//  ViewController.m
//  Task2Lab7
//
//  Created by Ivan on 17.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import "ViewController.h"

///Dicitionary for pairs  <temperature, city>
NSDictionary *temperatures;

///Dicitionary for pairs  <temperature, city>
NSDictionary *places;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   temperatures =[NSMutableDictionary dictionary];
    
    places =[NSMutableDictionary dictionary];
    
    
    
    ///Initializing temperatures dictionary.
    [temperatures setValue:[NSNumber numberWithInt:10] forKey:@"Minsk"];
    [temperatures setValue:[NSNumber numberWithInt:31] forKey:@"Milan"];
    [temperatures setValue:[NSNumber numberWithInt:39] forKey:@"Rome"];
    [temperatures setValue:[NSNumber numberWithInt:18] forKey:@"Moscow"];
    [temperatures setValue:[NSNumber numberWithInt:18] forKey:@"Barcelona"];
     [temperatures setValue:[NSNumber numberWithInt:18] forKey:@"Madrid"];
    [temperatures setValue:[NSNumber numberWithInt:-8] forKey:@"Brest"];
    [temperatures setValue:[NSNumber numberWithInt:23] forKey:@"Tokyo"];
     [temperatures setValue:[NSNumber numberWithInt:23] forKey:@"Osaka"];
     [temperatures setValue:[NSNumber numberWithInt:13] forKey:@"Yerevan"];
     [temperatures setValue:[NSNumber numberWithInt:24] forKey:@"Gyumri"];
    
    //Initializing museums dictionary.
      [places setValue:@"State museum" forKey:@"Minsk"];
      [places setValue:@"Fondazione-prada" forKey:@"Milan"];
    [places setValue:@"Bargese gallery" forKey:@"Rome"];
      [places setValue:@"Armoury camber" forKey:@"Moscow"];
      [places setValue:@"Fundacioo Joan" forKey:@"Barcelona"];
    [places setValue:@"Museum ceralba" forKey:@"Madrid"];
      [places setValue:@"Brest hero-fortress" forKey:@"Brest"];
      [places setValue:@"Folk crafts museum" forKey:@"Tokyo"];
     [places setValue:@"Museum of history" forKey:@"Osaka"];
    [places setValue:@"Cafesjian museum" forKey:@"Yerevan"];
    [places setValue:@"Museum of architecture" forKey:@"Gyumri"];
    
    // Do any additional setup after loading the view.
}

//Handles confirm button click
- (IBAction)ConfirmButtonClicked:(id)sender {
    
    NSString *cityName= _InputField.text;
    
    NSNumber *temperatur = [temperatures objectForKey:cityName];
    
    NSString *museum=[places objectForKey:cityName];
    
    if(temperatur==nil){
        _Temperature.text=@"No city found";
    }
    else{
        _Temperature.text=( [[temperatur stringValue] stringByAppendingString:@" C"] );
        
        _MuseumLabel.text=museum;
        _ImageView.image=[UIImage imageNamed:museum];
        
        
        
    }
}

@end
