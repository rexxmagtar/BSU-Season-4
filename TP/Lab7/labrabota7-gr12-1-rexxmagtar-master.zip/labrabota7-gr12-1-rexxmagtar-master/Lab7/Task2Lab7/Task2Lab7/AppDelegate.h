//
//  AppDelegate.h
//  Task2Lab7
//
//  Created by Ivan on 17.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

