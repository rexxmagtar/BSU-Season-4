//
//  ViewController.swift
//  Task4
//
//  Created by Ivan on 18.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
       }

    //Handles pendulum type change
       @IBAction func TypeChanged(_ sender: Any) {
           
           if(TypeField.selectedSegmentIndex==1){
               ParamNameLabel.text = "масса (кг)";
           }
           else{
               ParamNameLabel.text = "длина (м)";
           }
       }
       
    //Solve "calculate" button click
       @IBAction func SolveButtonPressed(_ sender: Any) {
           
           var answer = 0.1;
           var param = Double(ParamField.text!);
           
           if(TypeField.selectedSegmentIndex==1){
               answer=2*3.14*sqrt(param!/100);
           }
           else{
               answer=2*3.14*sqrt(param!/9.81);
           }
           
           ResultLabel.text = "T = "+String(answer)+" c";
       }
       
       @IBOutlet weak var ResultLabel: UILabel!
       @IBOutlet weak var TypeField: UISegmentedControl!
       @IBOutlet weak var ParamNameLabel: UILabel!
       @IBOutlet weak var ParamField: UITextField!

}

