//
//  User+CoreDataClass.swift
//  task2.2Lab9
//
//  Created by Ivan on 29.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//
//

import Foundation
import CoreData


public class User: NSManagedObject {

}
