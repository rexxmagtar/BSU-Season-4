# labrabota10gruppa1-vm
labrabota10gruppa1-vm created by GitHub Classroom
[![Build Status](https://travis-ci.com/tp2020/labrabota10gruppa1-vm.svg?branch=master)](https://travis-ci.com/tp2020/labrabota10gruppa1-vm)
# Project Name: 
BusRoutes
# Description:
This project helps to book ticket for different international buss routes.
# Installation:
1. Download app
2. Run main app
# Usage:
1. During first run you should give all required permissions to app.
2. Go to Registartion menu.
3. In main menu you can get all available information about routs you want. Just fill "From" and "To" input fields
# Credits:
Shishlynnikov Ivan: frontEnd,backEnd, CEO, QA
