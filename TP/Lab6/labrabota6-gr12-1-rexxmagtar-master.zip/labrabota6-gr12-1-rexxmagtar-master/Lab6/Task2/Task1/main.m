//
//  main.m
//  TestCommand
//
//  Created by Ivan on 31.03.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        int result=1;
        for (int i=1; i<=10; i++) {
             result*=i;
            NSLog(@"Factorial of %d = %d \n",i,result);
           
        }
    }
    return 0;
}
