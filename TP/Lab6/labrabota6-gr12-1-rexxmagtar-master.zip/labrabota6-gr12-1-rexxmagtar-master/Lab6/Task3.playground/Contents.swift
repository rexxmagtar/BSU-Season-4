import Cocoa
import Foundation

var number = 0;


var input = "39"



number = Int(input)!



//code starts here...


var convertedNumber = String(number)

if(convertedNumber.contains("3") || convertedNumber.contains("7")){
    print("Number contains 3 or 7 \n")
}

if((convertedNumber.contains("4") && convertedNumber.contains("8")) || convertedNumber.contains("9")){
    print("Number contains (4 and 8) or 9 \n")
}

