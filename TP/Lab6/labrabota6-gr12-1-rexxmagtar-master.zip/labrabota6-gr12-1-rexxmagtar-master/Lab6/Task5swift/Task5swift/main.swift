//
//  main.swift
//  Task5swift
//
//  Created by Ivan on 04.04.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import Foundation

var input:String;

       setlocale(LC_ALL,"Russian");
input=readLine()!;

var words = input.split(separator:" ")

       
var result: [String] = []

       
       var regex = "^[а-я|\n]+"


       
for i in 0...words.count-1{
    if(((words[i].range(of: regex, options: .regularExpression))==nil)==false ){
        result.append(String(words[i]))
    }
       }
       


       setlocale(LC_ALL,"Russian");
       
       

result.sort()

for i in (0..<result.count).reversed() {
    print(result[i]+" ")
}


