//
//  ViewController.swift
//  Task1.2Lab9
//
//  Created by Ivan on 01.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
         RegView.isHidden=true;
        // Do any additional setup after loading the view.
        
        if((UserDefaults.standard.object(forKey: "login")) != nil){
            performSegue(withIdentifier: "closeZone", sender: self);
        }
    }
    @IBAction func LoginInputField(_ sender: Any) {
    }
    
    @IBAction func StetSwitch(_ sender: Any) {
        if(LOginRegSwitch.selectedSegmentIndex==1){
            RegView.isHidden=false;
        }
        else{
            RegView.isHidden=true;
        }
        
    }
    @IBOutlet weak var LoginInput: UITextField!
    @IBAction func RegConfButton(_ sender: Any) {
        UserDefaults.standard.set(LoginReg.text!,forKey: "login")
        UserDefaults.standard.set(PassReg.text!,forKey: "password")
        performSegue(withIdentifier: "closeZone", sender: self);
    }
    @IBOutlet weak var RegView: UIView!
    @IBOutlet weak var PasswordInputField: UITextField!
    @IBOutlet weak var LoginReg: UITextField!
    
    @IBOutlet weak var PassReg: UITextField!
    @IBOutlet weak var EmailReg: UITextField!
    @IBOutlet weak var RepPassReg: UITextField!
    @IBOutlet weak var LOginRegSwitch: UISegmentedControl!
}

