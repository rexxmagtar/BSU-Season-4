//
//  ViewController.swift
//  task1.3Lab9
//
//  Created by Ivan on 06.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate {

    var locManager=CLLocationManager();
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        locManager.delegate=self;
        locManager.requestWhenInUseAuthorization();
        locManager.startUpdatingLocation();
        
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        var text="";
        LocationText.text="";
        for location in locations {
            print(location);
            LocationText.text.append(String( location.description));
        }
    }
    @IBOutlet weak var LocationText: UITextView!
    
}

