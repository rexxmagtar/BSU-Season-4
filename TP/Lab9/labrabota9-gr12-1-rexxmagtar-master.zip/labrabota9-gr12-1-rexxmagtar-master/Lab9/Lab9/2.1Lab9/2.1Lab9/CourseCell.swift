//
//  CourseCell.swift
//  2.1Lab9
//
//  Created by Ivan on 14.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import Foundation
import UIKit

class CourseCell: UICollectionViewCell{
    
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Icon: UIImageView!
    
}
