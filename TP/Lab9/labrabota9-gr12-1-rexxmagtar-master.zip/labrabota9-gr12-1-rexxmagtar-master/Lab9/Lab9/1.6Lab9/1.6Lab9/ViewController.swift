//
//  ViewController.swift
//  1.6Lab9
//
//  Created by Ivan on 09.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {

                
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var InputField: UITextField!
    @IBOutlet weak var Table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Table.delegate=self;
        
    }

    var students = [NSManagedObject]();
    
             func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
    return 1 }
    func     tableView(_ tableView:     UITableView, numberOfRowsInSection section: Int) -> Int
          {         return
    students.count      }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
         {
            let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell")! as UITableViewCell
             
            let student = students[indexPath.row];
            cell.textLabel?.text = student.value(forKey: "name") as? String //Заполняем текст ячейки таблицы значением ключа "name"
                     return cell
         }
    private func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCell.EditingStyle, forRowAtIndexPath indexPath: IndexPath)
    {
        if editingStyle == UITableViewCell.EditingStyle.delete
            {
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //Создаем ссылку на класс AppDelegate из файла AppDelegate.swift
                let managedObjectContext = appDelegate.persistentContainer.viewContext;
                //Создаем ссылку на метод managedObjectContext из класса AppDelegate в файле AppDelegate.swift
                 
                managedObjectContext.delete(students[indexPath.row]     as NSManagedObject) //Выбираем метод удалени объекта из модели данных students
                               do
                {
                    try managedObjectContext.save() //Пробуем сохранить изменения в базе данных
                    students.remove(at: indexPath.row) //Удаляем объект из модели students
                    tableView.deleteRows(at:[indexPath],with: .left) //Удаляем строку из таблицы
                }
                catch let error as NSError
                {
                    print("Data removing error: \(error)") //В случае возникновения ошибки, выводим; ее в консоль
                }
            }
     
    }

    @IBAction func addStudentButton(sender: AnyObject)
    {
            if (InputField.text == "" || InputField.text == "Введите данные!"){
                InputField.text = "Введите данные!"
        }
        else {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //Создаем ссылку на класс AppDelegate из файла AppDelegate.swift

     
                let     newObject     =
                    NSEntityDescription.insertNewObject(forEntityName: "Students", into: appDelegate.persistentContainer.viewContext) as NSManagedObject ;
                 
                newObject.setValue(InputField.text!,     forKey:     "name")
    //Значением нового объекта для ключа "name" будет являться текст из текстового поля studentNameTextField
                do
                {
                    try appDelegate.persistentContainer.viewContext.save() //Пробуем сохранить изменения в модели
                    students.append(newObject) //Добавляем новый объект в модель данных students
                     InputField.text! = "" //Очищаем текстовое поле
                    self.Table.reloadData();
                    //Обновляем         содержимое         таблицы
    self.view.endEditing(true) //Убираем клавиатуру с экрана и выходим из режима редактирования
                }
                catch let error as NSError
                {
                    print("Data saving error: \(error)") //В случае возникновения ошибки, выводим ее в консоль
                }
            }
    }
     
    override func viewWillAppear(_ animated: Bool)
    {
            super.viewWillAppear(animated)
             
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
    //Создаем ссылку на класс AppDelegate
             
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Students") //Создаем запрос из сущности "Students"
            do
            {
                students =  (try appDelegate.persistentContainer.viewContext.fetch((fetchRequest))  as! [NSManagedObject]) //Пробуем загрузить запрошенные данные в модель students
            }
            catch let error as NSError
            {
                print("Data loading error: \(error)")
            }
        self.Table.reloadData();
        //Обновляем содержимое таблицы

}


}

 


