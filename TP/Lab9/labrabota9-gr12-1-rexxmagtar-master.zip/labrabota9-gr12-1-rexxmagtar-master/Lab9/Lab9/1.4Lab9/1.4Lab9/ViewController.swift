//
//  ViewController.swift
//  1.4Lab9
//
//  Created by Ivan on 08.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    var locationManager = CLLocationManager();
    
    @IBOutlet weak var MapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate=self;
        locationManager.distanceFilter=kCLLocationAccuracyNearestTenMeters;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        
        // 3. setup mapView
           MapView.delegate = self
           MapView.showsUserLocation = true
        MapView.userTrackingMode = .follow
        
           // 4. setup test data
           setupData()
        
        locationManager.startUpdatingLocation();
        
        
        // Do any additional setup after loading the view.
    }
    
    func setupData() {
        // 1. check if system can monitor regions
        if CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) {
     
            // 2. region data
            let title = "BSU"
            let coordinate = CLLocationCoordinate2DMake(53.893026, 27.54)
            let regionRadius = 300.0
     
            // 3. setup region
            let region = CLCircularRegion(center: CLLocationCoordinate2D(latitude: coordinate.latitude,
                longitude: coordinate.longitude), radius: regionRadius, identifier: title)
            locationManager.startMonitoring(for: region)
     
            // 4. setup annotation
            let restaurantAnnotation = MKPointAnnotation()
            restaurantAnnotation.coordinate = coordinate;
            restaurantAnnotation.title = "\(title)";
            MapView.addAnnotation(restaurantAnnotation)
     
            // 5. setup circle
            let circle = MKCircle(center: coordinate, radius: regionRadius)
            MapView.addOverlay(circle)
        }
        else {
            print("System can't track regions")
        }
    }
     
        // 6. draw circle
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            let circleRenderer = MKCircleRenderer(overlay: overlay)
            circleRenderer.strokeColor = UIColor.red
            circleRenderer.lineWidth = 1.0
            return circleRenderer
        }
    
    


}

