//
//  ViewController.m
//  1.5Lab9
//
//  Created by Ivan on 08.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
