//
//  ViewController.h
//  1.5Lab9
//
//  Created by Ivan on 08.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>


@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet MKMapView *map;



@end

