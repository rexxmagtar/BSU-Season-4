//
//  Test.swift
//  1.5Lab9
//
//  Created by Ivan on 09.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import Foundation
@class TestCLass{
    
    var a=2;
}
