//
//  Record+CoreDataProperties.swift
//  1.5Lab9
//
//  Created by Ivan on 09.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//
//

import Foundation
import CoreData


extension Record {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Record> {
        return NSFetchRequest<Record>(entityName: "Record")
    }

    @NSManaged public var aviaCompany: String?
    @NSManaged public var cityTo: String?
    @NSManaged public var cityFrom: String?
    @NSManaged public var price: Float

}
