//
//  AppDelegate.m
//  1.5Lab9
//
//  Created by Ivan on 08.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize
managedObjectContext,managedObjectModel,persistentStoreCoordinator;

// 1
- (NSManagedObjectContext *) managedObjectContext {     if (managedObjectContext != nil) {         return managedObjectContext;     }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        managedObjectContext = [[NSManagedObjectContext alloc] init];         [managedObjectContext setPersistentStoreCoordinator: coordinator];     }         return managedObjectContext; }

//2
- (NSManagedObjectModel *)managedObjectModel {
    if (managedObjectModel != nil) {         return managedObjectModel;     }
    managedObjectModel = [NSManagedObjectModel mergedModelFromBundles:nil];
        return managedObjectModel; }
- (NSURL *)applicationDocumentsDirectory {     return [[[NSFileManager defaultManager]
URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

//3
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {     if (persistentStoreCoordinator != nil) {         return persistentStoreCoordinator;     }
    
    NSURL *storeURL = [[self applicationDocumentsDirectory]
URLByAppendingPathComponent:@"flight.sqlite"];
        NSError *error = nil;     persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
        if (![persistentStoreCoordinator
addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        
    }
        return persistentStoreCoordinator;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
