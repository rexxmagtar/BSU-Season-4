//
//  ViewController.swift
//  1.1Lab9
//
//  Created by Ivan on 06.05.2020.
//  Copyright © 2020 Ivan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadData()
    }

    func loadData(){
        

        var bundlePath = Bundle.main.path(forResource: "MyList", ofType: "plist");
        var result = NSMutableDictionary(contentsOfFile: bundlePath!)
        
        var text="";
        
        for pair in result! {
            text.append(pair.key as! String+": "+(pair.value as! String)+"\n")
        }
        
        ResultText.text=text;
        
    }
    @IBOutlet weak var ResultText: UITextView!
}

